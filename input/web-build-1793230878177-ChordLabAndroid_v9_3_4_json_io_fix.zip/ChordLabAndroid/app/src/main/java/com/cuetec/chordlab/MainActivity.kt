package com.cuetec.chordlab

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.WindowManager
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSaveContent: String? = null
    private var pendingSaveFilename: String = "chord-lab-session.json"

    companion object {
        private const val REQUEST_OPEN_JSON = 4101
        private const val REQUEST_SAVE_JSON = 4102
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 32, 46))
        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = false
        webView.overScrollMode = View.OVER_SCROLL_NEVER

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
        }

        webView.addJavascriptInterface(AndroidFileBridge(), "ChordLabAndroid")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/json", "text/plain", "application/octet-stream"))
                }
                return try {
                    startActivityForResult(intent, REQUEST_OPEN_JSON)
                    true
                } catch (_: Exception) {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = null
                    Toast.makeText(this@MainActivity, "Dateiauswahl konnte nicht geöffnet werden", Toast.LENGTH_LONG).show()
                    false
                }
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                android.util.Log.d(
                    "ChordLab",
                    "${consoleMessage.message()} -- line ${consoleMessage.lineNumber()}"
                )
                return true
            }
        }

        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private inner class AndroidFileBridge {
        @JavascriptInterface
        fun saveTextFile(filename: String, content: String) {
            runOnUiThread {
                pendingSaveFilename = filename.substringAfterLast('/').ifBlank { "chord-lab-session.json" }
                pendingSaveContent = content
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, pendingSaveFilename)
                }
                try {
                    startActivityForResult(intent, REQUEST_SAVE_JSON)
                } catch (_: Exception) {
                    pendingSaveContent = null
                    Toast.makeText(this@MainActivity, "Speichern ist auf diesem Gerät nicht verfügbar", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OPEN_JSON -> {
                val callback = fileChooserCallback
                fileChooserCallback = null
                if (resultCode == Activity.RESULT_OK && data?.data != null) {
                    callback?.onReceiveValue(arrayOf(data.data!!))
                } else {
                    callback?.onReceiveValue(null)
                }
            }
            REQUEST_SAVE_JSON -> {
                val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
                val content = pendingSaveContent
                pendingSaveContent = null
                if (uri != null && content != null) {
                    try {
                        contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                            ?: throw IOException("Could not open destination")
                        webView.evaluateJavascript("document.getElementById('sessionstatus').textContent='Session JSON saved successfully.';", null)
                        Toast.makeText(this, "Chord Lab Session gespeichert", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Speichern fehlgeschlagen: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("ChordLabAndroid")
        webView.destroy()
        super.onDestroy()
    }
}
