Chord Lab Android v9.8.5

Repair: removed startup bindings for legacy sequencer and piano-roll controls that are not present in the current 16-pad interface. Reworked rendering and session restore to match the current HTML. Save Session now serializes the 16 individual pad chord-colour and octave settings as well as the shared controls. The sample tape-deck initialization now runs after the main app initialization completes.

The Android file bridge and Storage Access Framework result handlers were inspected and retained.

Build the APK using the AndroidForge workflow. JavaScript syntax and ZIP integrity were checked locally. This ZIP has not been built or tested on a physical Android device in this environment.
