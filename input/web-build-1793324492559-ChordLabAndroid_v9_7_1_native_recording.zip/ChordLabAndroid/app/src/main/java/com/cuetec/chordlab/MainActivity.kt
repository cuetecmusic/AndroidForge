package com.cuetec.chordlab

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.media.MediaRecorder
import android.util.Base64
import java.io.File
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import android.os.Bundle
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.WindowManager
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSaveContent: String? = null
    private var pendingSaveFilename: String = "chord-lab-session.json"
    private lateinit var midiManager: MidiManager
    private var connectedMidiDevice: MidiDevice? = null
    private var connectedMidiInputPort: MidiInputPort? = null
    private var pendingWebPermissionRequest: PermissionRequest? = null
    private var pendingNativeRecordingStart = false
    private var nativeRecorder: MediaRecorder? = null
    private var nativeRecordingFile: File? = null

    companion object {
        private const val REQUEST_OPEN_JSON = 4101
        private const val REQUEST_SAVE_JSON = 4102
        private const val REQUEST_MICROPHONE = 4103
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        midiManager = getSystemService(MIDI_SERVICE) as MidiManager

        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 32, 46))
        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = false
        webView.overScrollMode = View.OVER_SCROLL_NEVER

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
        }

        webView.addJavascriptInterface(AndroidFileBridge(), "ChordLabAndroid")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsAudio = request.resources?.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) == true
                    if (!wantsAudio) {
                        request.deny()
                        return@runOnUiThread
                    }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    } else {
                        pendingWebPermissionRequest?.deny()
                        pendingWebPermissionRequest = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE)
                    }
                }
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                android.util.Log.d(
                    "ChordLab",
                    "${consoleMessage.message()} -- line ${consoleMessage.lineNumber()}"
                )
                return true
            }
        }

        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    inner class AndroidFileBridge {
        @JavascriptInterface
        fun listMidiDevices(): String {
            val result = JSONArray()
            try {
                for (info in midiManager.devices) {
                    for (port in info.ports) {
                        if (port.type == MidiDeviceInfo.PortInfo.TYPE_INPUT) {
                            val item = JSONObject()
                            item.put("id", info.id)
                            item.put("port", port.portNumber)
                            val props = info.properties
                            item.put("name", props.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "USB MIDI device")
                            result.put(item)
                        }
                    }
                }
            } catch (_: Exception) { }
            return result.toString()
        }

        @JavascriptInterface
        fun connectMidi(deviceId: Int, portNumber: Int) {
            runOnUiThread {
                closeMidiPort()
                val info = midiManager.devices.firstOrNull { it.id == deviceId }
                if (info == null) {
                    notifyMidi(false, "MIDI device disappeared. Scan again.")
                    return@runOnUiThread
                }
                try {
                    midiManager.openDevice(info, { device ->
                        if (device == null) {
                            notifyMidi(false, "Could not open MIDI device.")
                            return@openDevice
                        }
                        try {
                            val port = device.openInputPort(portNumber)
                            if (port == null) {
                                device.close()
                                notifyMidi(false, "Could not open MIDI input port.")
                            } else {
                                connectedMidiDevice = device
                                connectedMidiInputPort = port
                                notifyMidi(true, "Connected · " + (info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI device"))
                            }
                        } catch (e: Exception) {
                            try { device.close() } catch (_: Exception) { }
                            notifyMidi(false, "MIDI connect failed: " + (e.message ?: "unknown error"))
                        }
                    }, Handler(Looper.getMainLooper()))
                } catch (e: Exception) {
                    notifyMidi(false, "MIDI connect failed: " + (e.message ?: "unknown error"))
                }
            }
        }

        @JavascriptInterface
        fun sendMidi(status: Int, data1: Int, data2: Int) {
            try {
                val bytes = byteArrayOf(status.toByte(), data1.toByte(), data2.toByte())
                connectedMidiInputPort?.send(bytes, 0, bytes.size)
            } catch (e: Exception) {
                runOnUiThread { notifyMidi(false, "MIDI send failed: " + (e.message ?: "unknown error")) }
            }
        }

        @JavascriptInterface
        fun disconnectMidi() {
            runOnUiThread { closeMidiPort(); notifyMidi(false, "MIDI disconnected.") }
        }

        @JavascriptInterface
        fun startAudioRecording() {
            runOnUiThread {
                if (nativeRecorder != null) {
                    notifyNativeRecordingError("A recording is already in progress.")
                    return@runOnUiThread
                }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    pendingNativeRecordingStart = true
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE)
                } else {
                    beginNativeRecording()
                }
            }
        }

        @JavascriptInterface
        fun stopAudioRecording() {
            runOnUiThread { finishNativeRecording() }
        }

        @JavascriptInterface
        fun saveTextFile(filename: String, content: String) {
            runOnUiThread {
                pendingSaveFilename = filename.substringAfterLast('/').ifBlank { "chord-lab-session.json" }
                pendingSaveContent = content
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, pendingSaveFilename)
                }
                try {
                    startActivityForResult(intent, REQUEST_SAVE_JSON)
                } catch (_: Exception) {
                    pendingSaveContent = null
                    Toast.makeText(this@MainActivity, "Speichern ist auf diesem Gerät nicht verfügbar", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun openTextFile() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/json", "text/plain", "application/octet-stream"))
                }
                try {
                    startActivityForResult(intent, REQUEST_OPEN_JSON)
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Dateiauswahl konnte nicht geöffnet werden", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun beginNativeRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            notifyNativeRecordingError("Microphone permission was not granted.")
            return
        }
        try {
            val output = File(cacheDir, "chordlab_take_${System.currentTimeMillis()}.m4a")
            val recorder = MediaRecorder()
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioEncodingBitRate(128000)
            recorder.setAudioSamplingRate(44100)
            recorder.setMaxDuration(24000)
            recorder.setOutputFile(output.absolutePath)
            recorder.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {
                    runOnUiThread { finishNativeRecording() }
                }
            }
            recorder.setOnErrorListener { _, what, extra ->
                runOnUiThread {
                    notifyNativeRecordingError("Android recorder error ($what/$extra).")
                    releaseNativeRecorder(deleteFile = true)
                }
            }
            recorder.prepare()
            recorder.start()
            nativeRecorder = recorder
            nativeRecordingFile = output
            webView.evaluateJavascript("window.hclNativeRecordingStarted && window.hclNativeRecordingStarted();", null)
        } catch (e: Exception) {
            releaseNativeRecorder(deleteFile = true)
            notifyNativeRecordingError("Could not start microphone recording: " + (e.message ?: "unknown error"))
        }
    }

    private fun finishNativeRecording() {
        val recorder = nativeRecorder ?: return
        val output = nativeRecordingFile
        try {
            recorder.stop()
            recorder.reset()
            recorder.release()
            nativeRecorder = null
            nativeRecordingFile = null
            if (output == null || !output.exists() || output.length() <= 0L) {
                output?.delete()
                notifyNativeRecordingError("No audio was captured. Please try a longer recording.")
                return
            }
            val bytes = output.readBytes()
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val mime = "audio/mp4"
            val quotedData = JSONObject.quote(encoded)
            val quotedMime = JSONObject.quote(mime)
            webView.evaluateJavascript(
                "window.hclNativeRecordingComplete && window.hclNativeRecordingComplete($quotedData, $quotedMime);",
                null
            )
            output.delete()
        } catch (e: RuntimeException) {
            releaseNativeRecorder(deleteFile = true)
            notifyNativeRecordingError("Recording was too short or could not be finalized.")
        } catch (e: Exception) {
            releaseNativeRecorder(deleteFile = true)
            notifyNativeRecordingError("Could not finish recording: " + (e.message ?: "unknown error"))
        }
    }

    private fun releaseNativeRecorder(deleteFile: Boolean) {
        try { nativeRecorder?.reset() } catch (_: Exception) { }
        try { nativeRecorder?.release() } catch (_: Exception) { }
        nativeRecorder = null
        if (deleteFile) {
            try { nativeRecordingFile?.delete() } catch (_: Exception) { }
        }
        nativeRecordingFile = null
    }

    private fun notifyNativeRecordingError(message: String) {
        val quoted = JSONObject.quote(message)
        webView.evaluateJavascript("window.hclNativeRecordingError && window.hclNativeRecordingError($quoted);", null)
    }

    private fun notifyMidi(connected: Boolean, message: String) {
        val safeMessage = JSONObject.quote(message)
        webView.evaluateJavascript("window.hclMidiConnectionChanged && window.hclMidiConnectionChanged($connected, $safeMessage);", null)
    }

    private fun closeMidiPort() {
        try { connectedMidiInputPort?.close() } catch (_: Exception) { }
        try { connectedMidiDevice?.close() } catch (_: Exception) { }
        connectedMidiInputPort = null
        connectedMidiDevice = null
    }

    @Deprecated("Deprecated in Android")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MICROPHONE) {
            val granted = grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val request = pendingWebPermissionRequest
            pendingWebPermissionRequest = null
            if (request != null) {
                if (granted) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                else request.deny()
            }
            if (pendingNativeRecordingStart) {
                pendingNativeRecordingStart = false
                if (granted) beginNativeRecording()
                else notifyNativeRecordingError("Microphone permission was denied.")
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OPEN_JSON -> {
                val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
                if (uri != null) {
                    try {
                        val content = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                            ?: throw IOException("Could not read selected file")
                        val quoted = org.json.JSONObject.quote(content)
                        webView.evaluateJavascript("window.hclReceiveSessionJson($quoted);", null)
                    } catch (e: Exception) {
                        Toast.makeText(this, "Laden fehlgeschlagen: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            REQUEST_SAVE_JSON -> {
                val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
                val content = pendingSaveContent
                pendingSaveContent = null
                if (uri != null && content != null) {
                    try {
                        contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                            ?: throw IOException("Could not open destination")
                        webView.evaluateJavascript("document.getElementById('sessionstatus').textContent='Session JSON saved successfully.';", null)
                        Toast.makeText(this, "Chord Lab Session gespeichert", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Speichern fehlgeschlagen: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        releaseNativeRecorder(deleteFile = true)
        pendingWebPermissionRequest?.deny()
        pendingWebPermissionRequest = null
        closeMidiPort()
        webView.removeJavascriptInterface("ChordLabAndroid")
        webView.destroy()
        super.onDestroy()
    }
}
