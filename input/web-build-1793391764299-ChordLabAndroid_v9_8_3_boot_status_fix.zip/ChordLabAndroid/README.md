Chord Lab Android v9.7.9

Change: Save Preset is dispatched explicitly from the document capture listener after a real click, with visible diagnostics. This targets the confirmed condition where the click is received but the assigned button handler does not appear to run.

Build the APK using the same AndroidForge workflow as before. This ZIP has not been built or tested on a physical Android device in this environment.
