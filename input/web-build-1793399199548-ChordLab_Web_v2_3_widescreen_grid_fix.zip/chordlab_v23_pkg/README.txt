Chord Lab by Cuetec — Web Edition 2.3

Landscape grid correction based on the 2.2 release candidate.
The five upper control racks now use a balanced 3+2 layout in landscape: three equal panels on row one, two half-width panels on row two. Narrow landscape phones fall back to a two-column layout.
Audio engine and musical behavior are unchanged from 2.2.

Open index.html in a modern browser or package it into the Android WebView project.
