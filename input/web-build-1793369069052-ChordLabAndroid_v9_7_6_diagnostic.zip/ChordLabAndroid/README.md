# Chord Lab by Cuetec — Android wrapper project

This Android Studio project packages the current `chord_lab_v9_2_minimal_audio_fix.html` build as a local WebView app. The HTML and its JavaScript run locally; no internet permission is requested.

## Build an APK

1. Install Android Studio (with Android SDK Platform 35 and Android SDK Build-Tools).
2. Open this folder (`ChordLabAndroid`) in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. For a test APK, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the output location, usually `app/build/outputs/apk/debug/app-debug.apk`.

For a signed release APK, use **Build → Generate Signed Bundle / APK…** and create or select a keystore.

## Notes

- Package/application ID: `com.cuetec.chordlab`
- Minimum Android version: Android 8.0 (API 26)
- The app is a WebView shell around the HTML version included in `app/src/main/assets/index.html`.
- Audio playback and touch behavior should be tested on the target phone. This environment did not have the Android SDK or Gradle installed, so an APK has not been compiled here.


Latest UI update: v9.3 fixes the phone landscape grid so the six control panels are balanced in three columns (two columns on very narrow landscape screens). Audio engine remains unchanged from v9.2.


## Version 1.1 update
- Moved session Load/Save controls into the top-right app header.
- Reorganized progression and step sequencer into a clearer side-by-side workspace on wider screens, stacking responsively on phones.


## Android file and recording bridge (v9.7.2)
- WebView file inputs are handled by `WebChromeClient.onShowFileChooser` and Android's document picker.
- Session JSON saving uses `ChordLabAndroid.saveTextFile` and Android's create-document picker.
- Recorded audio saving uses `ChordLabAndroid.saveBase64File` and Android's create-document picker.
- Microphone capture uses the native Android `MediaRecorder` bridge.
